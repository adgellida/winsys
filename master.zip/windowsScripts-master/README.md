# windowsScripts
A collection of windows scripts to fix problems and add functionalities
